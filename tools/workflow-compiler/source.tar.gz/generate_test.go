package workflow

import (
	"os"
	"testing"
)

func TestGeneratedArtifactsAreDeterministic(t *testing.T) {
	src, _ := os.ReadFile("examples/booking.yaml")
	b, e := Compile(src)
	if e != nil {
		t.Fatal(e)
	}
	for _, lang := range []string{"python", "typescript"} {
		first, e := Generate(b, lang)
		if e != nil {
			t.Fatal(e)
		}
		second, e := Generate(b, lang)
		if e != nil || Digest(first) != Digest(second) {
			t.Fatal("non-deterministic generation")
		}
		if !first[1].UserOwned {
			t.Fatal("adapter is not protected")
		}
	}
}

func TestToolingPatchPreservesPublishedBundleCompatibility(t *testing.T) {
	b, in := booking(t)
	b.CompilerVersion = "0.1.0"
	if _, err := Evaluate(b, in); err != nil {
		t.Fatalf("published verifier bundle rejected after a tooling patch: %v", err)
	}
	if ToolVersion == Version {
		t.Fatal("tooling and verifier version must be independently pinned")
	}
}
