# Booking reschedule

After installation, run `axonpush workflow action-test --file workflow.yaml --fixture review.json` to exercise the review policy entirely offline. The included next-day move must return `review`. Change it to an appointment on the same local day and set `expected` to `ready` to exercise the routine path.

Install the package in a new directory with `axonpush workflow init --template booking-reschedule --out booking-demo`. From that directory run `axonpush workflow generate --language python` or `--language typescript`. The CLI writes the typed builders and handler interfaces alongside a user-owned implementation stub.

Use the Python SDK from this checkout for the example. Set `AXONPUSH_API_URL`, `AXONPUSH_WORKSPACE` and `AXONPUSH_ENVIRONMENT` to a dedicated development deployment. Set `AXONPUSH_API_KEY` to a worker key scoped to that workspace's app and environment with `events:publish` and `workflows:execute`. Set `AXONPUSH_WORKER_KEY_ID` to its key ID. Set `AXONPUSH_AUTHOR_KEY` to a separate development key with `workspaces:manage`, `workflows:propose` and `observe:read`. The author's key is needed for the scenario runner only.

```sh
python scenario.py routine --install
python scenario.py review
python scenario.py mismatch
python scenario.py unavailable
python worker.py
```

The first command explicitly activates the contract for new cases and binds the calendar handler. The runner seeds a synthetic SQLite booking and uses real HTTP endpoints. Use the same working directory or set CALENDAR_DB to the same file for every invocation. Needs attention shows the three outstanding examples. Approve or edit the review, correct the mismatched booking, and recheck the unavailable lookup. With the example worker running all three should reach verified after a fresh calendar read. Inspect each action's history. Existing business case identity, source access and the record's concurrency token must be mapped when replacing SQLite with a real provider.

The booking rule uses America/New_York to compare local days. Routine changes at the same location can run immediately. Changes outside that rule wait for a human. The credential used for reading the customer calendar stays in the worker.
