"""Run synthetic acceptance scenarios against a dedicated development deployment."""
import argparse
import os
import uuid
from pathlib import Path

import worker
from axonpush.workflow_worker import WorkflowWorker


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("scenario", choices=["routine", "review", "mismatch", "unavailable"])
    parser.add_argument("--install", action="store_true", help="Publish, activate and bind the calendar source in the selected dev deployment")
    args = parser.parse_args()
    source = WorkflowWorker.from_env("calendar")
    author = WorkflowWorker(os.environ["AXONPUSH_API_URL"], os.environ["AXONPUSH_WORKSPACE"], os.environ["AXONPUSH_ENVIRONMENT"], os.environ["AXONPUSH_AUTHOR_KEY"], "calendar")
    try:
        if args.install:
            definition = author.post("/definitions", {"source": Path(__file__).with_name("workflow.yaml").read_text()})
            author.post("/activation", {"version_id": definition["id"]})
            author.post("/sources", {"source": "calendar", "publisher": "key:" + os.environ["AXONPUSH_WORKER_KEY_ID"]})
        case = "demo-" + uuid.uuid4().hex[:16]
        baseline = {"booking_id": case, "person_ref": "demo-person", "service_ref": "consultation", "location": "main", "starts_at": "2026-11-24T14:00:00Z", "record_revision": 1}
        with worker.db:
            worker.db.execute("INSERT INTO bookings VALUES (:booking_id,:person_ref,:service_ref,:location,:starts_at,:record_revision)", baseline)
        key = source.post("/facts", {"workflow": "booking_reschedule", "input": {"case_id": case, "case_fields": baseline, "facts": [], "coverage": []}})["case_key"]
        change = {"starts_at": "2026-11-25T15:00:00Z" if args.scenario == "review" else "2026-11-24T15:00:00Z", "location": "main"}
        proposal = author.post(f"/cases/{key}/actions", {"name": "reschedule", "input": change, "request_id": case})
        expected = {"routine": "verified", "review": "review", "mismatch": "recovery", "unavailable": "unavailable"}[args.scenario]
        # Only introduce synthetic failures for this scenario's own test booking.
        def execute(action):
            if action["case_id"] == case and args.scenario == "mismatch":
                return {"record_revision": 1}
            return worker.execute(action)

        def lookup(action):
            if action["case_id"] == case and args.scenario == "unavailable":
                raise ConnectionError("Synthetic lookup outage")
            return worker.lookup(action)

        state = proposal["status"]
        for _ in range(32):
            if state == expected:
                print(f"{case} {state} (case key {key})")
                return
            source.tick(execute, lookup)
            result = author.client.get(author.url + "/actions", params={"environment": author.environment, "case_key": key})
            result.raise_for_status()
            state = next(a["status"] for a in result.json()["actions"] if a["id"] == proposal["id"])
        raise RuntimeError(f"Expected {expected}, observed {state}")
    finally:
        author.close()
        source.close()


if __name__ == "__main__":
    main()
