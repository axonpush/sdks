"""Run with python worker.py after installing the AxonPush Python SDK.
This example stores a synthetic calendar in SQLite. Use a separate DB per deployment.
"""
import os
import sqlite3
import hashlib
from pathlib import Path
from axonpush.workflow_worker import WorkflowWorker

db = sqlite3.connect(os.getenv("CALENDAR_DB", "calendar.sqlite"))
db.row_factory = sqlite3.Row
contract_file = Path(__file__).with_name("workflow.yaml")
supported_versions = {hashlib.sha256(content).hexdigest() for content in (contract_file.read_bytes(), contract_file.read_text().encode())}
with db:
    db.execute("CREATE TABLE IF NOT EXISTS bookings (booking_id TEXT PRIMARY KEY, person_ref TEXT, service_ref TEXT, location TEXT, starts_at TEXT, record_revision INTEGER)")
    db.execute("CREATE TABLE IF NOT EXISTS applied (operation TEXT PRIMARY KEY, revision INTEGER)")
    db.execute("INSERT OR IGNORE INTO bookings VALUES ('demo-booking','demo-person','consultation','main','2026-11-24T14:00:00Z',1)")


def lookup(action):
    if action["name"] != "reschedule" or action["version_id"] not in supported_versions:
        return {"result": "unavailable"}
    row = db.execute("SELECT * FROM bookings WHERE booking_id=?", (action["original"]["booking_id"],)).fetchone()
    if row is None:
        return {"result": "absent"}
    return {"result": "found", "observed": {"request_id": action["case_id"], **dict(row)}}


def execute(action):
    if action["name"] != "reschedule" or action["version_id"] not in supported_versions:
        raise ValueError("Worker cannot execute this contract revision")
    original, proposed = action["original"], action["input"]
    operation = f'{action["id"]}/{action["operation"]}'
    expected_revision = original["record_revision"]
    if action["operation"] > 1 and action.get("observed"):
        expected_revision = action["observed"]["record_revision"]
    with db:
        db.execute("BEGIN IMMEDIATE")
        replay = db.execute("SELECT revision FROM applied WHERE operation=?", (operation,)).fetchone()
        if replay:
            return {"record_revision": replay["revision"]}
        if action["operation"] == 1:
            baseline = db.execute("SELECT starts_at, location FROM bookings WHERE booking_id=?", (original["booking_id"],)).fetchone()
            if baseline is None or baseline["location"] != original["location"] or baseline["starts_at"] != original["starts_at"]:
                raise ValueError("Booking has changed since the case was opened")
        update = db.execute(
            "UPDATE bookings SET starts_at=?, location=?, record_revision=record_revision+1 WHERE booking_id=? AND person_ref=? AND service_ref=? AND record_revision=?",
            (proposed["starts_at"], proposed["location"], original["booking_id"], original["person_ref"], original["service_ref"], expected_revision),
        )
        if update.rowcount != 1:
            raise ValueError("Calendar revision or identity changed; read back before correction")
        db.execute("INSERT INTO applied VALUES (?,?)", (operation, expected_revision + 1))
    return {"record_revision": expected_revision + 1}


if __name__ == "__main__":
    WorkflowWorker.from_env("calendar").run(execute, lookup)
