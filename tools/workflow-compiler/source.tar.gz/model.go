// Package workflow compiles explicit workflow contracts and evaluates evidence.
// It does not execute business actions or perform network requests.
package workflow

import "time"

// Version is the verifier/bundle format; additive tooling does not invalidate existing contracts.
const Version = "0.1.0"

// ToolVersion pins CLI and deterministic generator output independently.
const ToolVersion = "0.1.1"

type Contract struct {
	SchemaVersion int                    `json:"schema_version" yaml:"schema_version"`
	Workflow      string                 `json:"workflow" yaml:"workflow"`
	Case          CaseSchema             `json:"case" yaml:"case"`
	Facts         map[string]FactSchema  `json:"facts" yaml:"facts"`
	Requirements  map[string]Requirement `json:"requirements" yaml:"requirements"`
	Presentation  Presentation           `json:"presentation" yaml:"presentation"`
	InitialState  string                 `json:"initial_state,omitempty" yaml:"initial_state,omitempty"`
	Actions       map[string]ActionSpec  `json:"actions,omitempty" yaml:"actions,omitempty"`
}
type CaseSchema struct {
	Key    string            `json:"key" yaml:"key"`
	Fields map[string]string `json:"fields,omitempty" yaml:"fields,omitempty"`
}
type FactSchema struct {
	Fields        map[string]string `json:"fields" yaml:"fields"`
	EvidenceClass string            `json:"evidence_class,omitempty" yaml:"evidence_class,omitempty"`
}
type Selector struct {
	Event string            `json:"event" yaml:"event"`
	Match map[string]string `json:"match,omitempty" yaml:"match,omitempty"`
	Where *Predicate        `json:"where,omitempty" yaml:"where,omitempty"`
}

// Predicate is a bounded expression tree. Field references start with case.,
// trigger. or evidence.; all other operands are explicit JSON scalar values.
type Predicate struct {
	All   []Predicate `json:"all,omitempty" yaml:"all,omitempty"`
	Any   []Predicate `json:"any,omitempty" yaml:"any,omitempty"`
	Field string      `json:"field,omitempty" yaml:"field,omitempty"`
	Op    string      `json:"op,omitempty" yaml:"op,omitempty"`
	Value any         `json:"value,omitempty" yaml:"value,omitempty"`
}
type Requirement struct {
	MaxMatches  int       `json:"max_matches,omitempty" yaml:"max_matches,omitempty"`
	EvidenceKey string    `json:"evidence_key,omitempty" yaml:"evidence_key,omitempty"`
	Trigger     Selector  `json:"trigger" yaml:"trigger"`
	Evidence    Selector  `json:"evidence" yaml:"evidence"`
	Failure     *Selector `json:"failure,omitempty" yaml:"failure,omitempty"`
	Cancel      *Selector `json:"cancel,omitempty" yaml:"cancel,omitempty"`
	Within      string    `json:"within" yaml:"within"`
	Grace       string    `json:"grace" yaml:"grace"`
	Source      string    `json:"source" yaml:"source"`
	FreshFor    string    `json:"fresh_for" yaml:"fresh_for"`
}
type Presentation struct {
	Title  string  `json:"title" yaml:"title"`
	Stages []Stage `json:"stages,omitempty" yaml:"stages,omitempty"`
}
type Stage struct {
	ID           string   `json:"id" yaml:"id"`
	Label        string   `json:"label" yaml:"label"`
	Requirements []string `json:"requirements" yaml:"requirements"`
}
type Bundle struct {
	CompilerVersion string   `json:"compiler_version"`
	SemanticHash    string   `json:"semantic_hash"`
	SourceHash      string   `json:"source_hash"`
	Contract        Contract `json:"contract"`
}
type Fact struct {
	ID         string         `json:"id"`
	Event      string         `json:"event"`
	CaseID     string         `json:"case_id"`
	Source     string         `json:"source"`
	OccurredAt time.Time      `json:"occurred_at"`
	ReceivedAt time.Time      `json:"received_at,omitempty"`
	Fields     map[string]any `json:"fields"`
	TraceID    string         `json:"trace_id,omitempty"`
	SpanID     string         `json:"span_id,omitempty"`
}

// Coverage is an assertion from a registered source, not an inference from a heartbeat.
type Coverage struct {
	Source          string    `json:"source"`
	CheckedAt       time.Time `json:"checked_at"`
	CompleteThrough time.Time `json:"complete_through"`
	Healthy         bool      `json:"healthy"`
}
type Input struct {
	Subjects   map[string]string `json:"subjects,omitempty"`
	CaseID     string            `json:"case_id"`
	CaseFields map[string]any    `json:"case_fields,omitempty"`
	Facts      []Fact            `json:"facts"`
	Coverage   []Coverage        `json:"coverage"`
	Now        time.Time         `json:"now,omitempty"`
	Previous   []Obligation      `json:"previous,omitempty"`
}
type Obligation struct {
	ID               string     `json:"id"`
	Requirement      string     `json:"requirement"`
	TriggerID        string     `json:"trigger_id"`
	State            string     `json:"state"`
	Lifecycle        string     `json:"lifecycle"`
	Timing           string     `json:"timing"`
	Reason           string     `json:"reason"`
	DueAt            time.Time  `json:"due_at"`
	DecideAt         time.Time  `json:"decide_at"`
	EvidenceIDs      []string   `json:"evidence_ids"`
	EvidenceClass    string     `json:"evidence_class"`
	BreachObservedAt *time.Time `json:"breach_observed_at,omitempty"`
}
type Result struct {
	CaseID       string       `json:"case_id"`
	SemanticHash string       `json:"semantic_hash"`
	EvaluatedAt  time.Time    `json:"evaluated_at"`
	Obligations  []Obligation `json:"obligations"`
}
