package workflow

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"regexp"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

var identifier = regexp.MustCompile(`^[a-z][a-z0-9_]{0,79}$`)
var eventName = regexp.MustCompile(`^[a-z][a-z0-9_.]{0,119}$`)

func hash(v []byte) string { h := sha256.Sum256(v); return hex.EncodeToString(h[:]) }
func Digest(v any) string  { b, _ := json.Marshal(v); return hash(b) }

func Compile(source []byte) (Bundle, error) {
	if len(source) == 0 || len(source) > 256*1024 {
		return Bundle{}, fmt.Errorf("contract must contain 1..262144 bytes")
	}
	var node yaml.Node
	d := yaml.NewDecoder(bytes.NewReader(source))
	if err := d.Decode(&node); err != nil {
		return Bundle{}, err
	}
	var extra yaml.Node
	if err := d.Decode(&extra); err != io.EOF {
		return Bundle{}, fmt.Errorf("exactly one YAML document is required")
	}
	count := 0
	if err := checkNode(&node, 0, &count); err != nil {
		return Bundle{}, err
	}
	var c Contract
	d = yaml.NewDecoder(bytes.NewReader(source))
	d.KnownFields(true)
	if err := d.Decode(&c); err != nil {
		return Bundle{}, err
	}
	if err := validate(c); err != nil {
		return Bundle{}, err
	}
	semantic := c
	semantic.Presentation = Presentation{}
	return Bundle{CompilerVersion: Version, SemanticHash: Digest(semantic), SourceHash: hash(source), Contract: c}, nil
}

func checkNode(n *yaml.Node, depth int, count *int) error {
	*count++
	if depth > 24 || *count > 10000 {
		return fmt.Errorf("line %d: YAML structure exceeds limits", n.Line)
	}
	if n.Kind == yaml.AliasNode || n.Anchor != "" {
		return fmt.Errorf("line %d: aliases and anchors are unsupported", n.Line)
	}
	if n.Tag != "" && !strings.HasPrefix(n.Tag, "!!") {
		return fmt.Errorf("line %d: custom tags are unsupported", n.Line)
	}
	if n.Kind == yaml.MappingNode {
		seen := map[string]bool{}
		for i := 0; i < len(n.Content); i += 2 {
			k := n.Content[i]
			if k.Kind != yaml.ScalarNode || k.Tag != "!!str" || seen[k.Value] {
				return fmt.Errorf("line %d: duplicate or non-string key %q", k.Line, k.Value)
			}
			seen[k.Value] = true
		}
	}
	for _, child := range n.Content {
		if err := checkNode(child, depth+1, count); err != nil {
			return err
		}
	}
	return nil
}

func duration(v string, allowZero bool) bool {
	d, e := time.ParseDuration(v)
	return e == nil && d <= 365*24*time.Hour && (d > 0 || allowZero && d == 0)
}
func validate(c Contract) error {
	if err := validateActions(c); err != nil {
		return err
	}
	if c.SchemaVersion != 1 {
		return fmt.Errorf("schema_version must be 1")
	}
	if !identifier.MatchString(c.Workflow) || !identifier.MatchString(c.Case.Key) {
		return fmt.Errorf("workflow and case.key must be lowercase identifiers")
	}
	if len(c.Facts) < 1 || len(c.Facts) > 100 || len(c.Requirements) < 1 || len(c.Requirements) > 100 {
		return fmt.Errorf("contract requires 1..100 facts and requirements")
	}
	for name, f := range c.Facts {
		for other := range c.Facts {
			if other != name && typeName(other) == typeName(name) {
				return fmt.Errorf("events %s and %s generate the same identifier", name, other)
			}
		}
		if !eventName.MatchString(name) || len(f.Fields) > 100 || f.Fields[c.Case.Key] != "string" {
			return fmt.Errorf("fact %s must declare case key %s as string", name, c.Case.Key)
		}
		if f.EvidenceClass != "" && f.EvidenceClass != "claim" && f.EvidenceClass != "application_record" && f.EvidenceClass != "provider_record" && f.EvidenceClass != "human_attestation" && f.EvidenceClass != "inferred" {
			return fmt.Errorf("fact %s: unsupported evidence class", name)
		}
		if err := fields(f.Fields); err != nil {
			return fmt.Errorf("fact %s: %w", name, err)
		}
	}
	if err := fields(c.Case.Fields); err != nil {
		return err
	}
	for name, r := range c.Requirements {
		if r.MaxMatches < 0 || r.MaxMatches > 100 || r.MaxMatches > 0 && c.Facts[r.Evidence.Event].Fields[r.EvidenceKey] != "string" {
			return fmt.Errorf("requirement %s: max_matches requires a string evidence_key", name)
		}
		if !identifier.MatchString(name) || !duration(r.Within, false) || !duration(r.Grace, true) || !duration(r.FreshFor, false) || !identifier.MatchString(r.Source) {
			return fmt.Errorf("requirement %s: valid within, grace, source and fresh_for are required", name)
		}
		for _, s := range []*Selector{&r.Trigger, &r.Evidence, r.Failure, r.Cancel} {
			if s != nil {
				if err := validateSelector(c, r, *s); err != nil {
					return fmt.Errorf("requirement %s: %w", name, err)
				}
			}
		}
	}
	seen := map[string]bool{}
	for _, s := range c.Presentation.Stages {
		if !identifier.MatchString(s.ID) || seen[s.ID] {
			return fmt.Errorf("invalid or repeated stage %s", s.ID)
		}
		seen[s.ID] = true
		for _, r := range s.Requirements {
			if _, ok := c.Requirements[r]; !ok {
				return fmt.Errorf("stage %s: unknown requirement %s", s.ID, r)
			}
		}
	}
	return nil
}
func fields(fs map[string]string) error {
	for k, t := range fs {
		if strings.Contains(" false none true and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield ", " "+k+" ") {
			return fmt.Errorf("field %s is a reserved generated-language identifier", k)
		}
		if !identifier.MatchString(k) {
			return fmt.Errorf("invalid field %s", k)
		}
		switch t {
		case "string", "number", "boolean", "timestamp":
		default:
			return fmt.Errorf("unsupported type %s", t)
		}
	}
	return nil
}
func fieldType(c Contract, r Requirement, s Selector, ref string) string {
	p := strings.SplitN(ref, ".", 2)
	if len(p) != 2 {
		return ""
	}
	switch p[0] {
	case "trigger":
		return c.Facts[r.Trigger.Event].Fields[p[1]]
	case "evidence":
		return c.Facts[s.Event].Fields[p[1]]
	case "case":
		return c.Case.Fields[p[1]]
	}
	return ""
}
func validateSelector(c Contract, r Requirement, s Selector) error {
	f, ok := c.Facts[s.Event]
	if !ok {
		return fmt.Errorf("unknown event %s", s.Event)
	}
	for k, ref := range s.Match {
		if f.Fields[k] == "" || f.Fields[k] != fieldType(c, r, s, ref) {
			return fmt.Errorf("invalid or incompatible match %s: %s", k, ref)
		}
	}
	return validatePredicate(c, r, s, s.Where, 0)
}
func validatePredicate(c Contract, r Requirement, s Selector, p *Predicate, depth int) error {
	if p == nil {
		return nil
	}
	if depth > 8 {
		return fmt.Errorf("predicate nesting exceeds 8")
	}
	if len(p.All) > 0 || len(p.Any) > 0 {
		if len(p.All) > 0 && len(p.Any) > 0 || p.Field != "" || p.Op != "" || p.Value != nil {
			return fmt.Errorf("predicate must have exactly one expression")
		}
		children := append(append([]Predicate{}, p.All...), p.Any...)
		if len(children) > 20 {
			return fmt.Errorf("predicate exceeds 20 children")
		}
		for _, v := range children {
			if e := validatePredicate(c, r, s, &v, depth+1); e != nil {
				return e
			}
		}
		return nil
	}
	t := fieldType(c, r, s, p.Field)
	if t == "" {
		return fmt.Errorf("unknown predicate field %s", p.Field)
	}
	switch p.Op {
	case "present":
		if p.Value != nil {
			return fmt.Errorf("present takes no value")
		}
	case "eq", "ne":
		if !validValue(t, p.Value) {
			return fmt.Errorf("predicate value does not match %s", t)
		}
	case "gt", "gte", "lt", "lte":
		if t != "number" && t != "timestamp" || !validValue(t, p.Value) {
			return fmt.Errorf("comparison requires a matching number or timestamp")
		}
	case "in":
		v, ok := p.Value.([]any)
		if !ok || len(v) == 0 || len(v) > 100 {
			return fmt.Errorf("in requires 1..100 values")
		}
		for _, x := range v {
			if !validValue(t, x) {
				return fmt.Errorf("invalid membership value")
			}
		}
	default:
		return fmt.Errorf("unsupported predicate operator %s", p.Op)
	}
	return nil
}
func validValue(t string, v any) bool {
	switch t {
	case "string":
		s, ok := v.(string)
		return ok && len(s) <= 4096
	case "boolean":
		_, ok := v.(bool)
		return ok
	case "number":
		switch n := v.(type) {
		case float64:
			return !math.IsNaN(n) && !math.IsInf(n, 0)
		case float32:
			return !math.IsNaN(float64(n)) && !math.IsInf(float64(n), 0)
		case int, int64, uint64:
			return true
		}
	case "timestamp":
		s, ok := v.(string)
		if !ok {
			return false
		}
		_, e := time.Parse(time.RFC3339Nano, s)
		return e == nil
	}
	return false
}
