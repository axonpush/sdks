package workflow

import (
	"errors"
	"fmt"
	"strings"
	"time"
	_ "time/tzdata"
)

// ReviewUnless compares proposed values to the immutable baseline in the case.
type ReviewUnless struct {
	Input    string `json:"input" yaml:"input"`
	Case     string `json:"case" yaml:"case"`
	Op       string `json:"op" yaml:"op"`
	Timezone string `json:"timezone,omitempty" yaml:"timezone,omitempty"`
}
type ActionSpec struct {
	Inputs      map[string]string `json:"inputs" yaml:"inputs"`
	Outputs     map[string]string `json:"outputs" yaml:"outputs"`
	From        string            `json:"from" yaml:"from"`
	To          string            `json:"to" yaml:"to"`
	Actors      []string          `json:"actors" yaml:"actors"`
	Handler     string            `json:"handler" yaml:"handler"`
	Requirement string            `json:"requirement" yaml:"requirement"`
	// Expected maps the trigger schema onto the approved input and case baseline.
	Expected     map[string]string `json:"expected" yaml:"expected"`
	ReviewUnless []ReviewUnless    `json:"review_unless,omitempty" yaml:"review_unless,omitempty"`
	AlwaysReview bool              `json:"always_review,omitempty" yaml:"always_review,omitempty"`
}

func validateActions(c Contract) error {
	if len(c.Actions) == 0 && c.InitialState == "" {
		return nil
	}
	if !identifier.MatchString(c.InitialState) || len(c.Actions) == 0 || len(c.Actions) > 100 {
		return errors.New("actions require an initial_state and 1..100 actions")
	}
	names := map[string]bool{}
	for name, a := range c.Actions {
		if !identifier.MatchString(name) || names[typeName(name)] || !identifier.MatchString(a.Handler) || !identifier.MatchString(a.From) || !identifier.MatchString(a.To) {
			return fmt.Errorf("action %q: invalid name, handler or transition", name)
		}
		names[typeName(name)] = true
		if len(a.Actors) == 0 {
			return fmt.Errorf("%s requires actors", name)
		}
		for _, actor := range a.Actors {
			if actor != "agent" && actor != "operator" {
				return fmt.Errorf("%s: unknown actor %s", name, actor)
			}
		}
		for _, fs := range []map[string]string{a.Inputs, a.Outputs} {
			if len(fs) == 0 || len(fs) > 100 {
				return fmt.Errorf("%s requires bounded input and output schemas", name)
			}
			if err := fields(fs); err != nil {
				return err
			}
		}
		r, ok := c.Requirements[a.Requirement]
		if !ok {
			return fmt.Errorf("%s: unknown completion requirement", name)
		}
		trigger := c.Facts[r.Trigger.Event].Fields
		if r.Source != a.Handler {
			return fmt.Errorf("%s: lookup handler must be the completion requirement's source", name)
		}
		if len(a.Expected) != len(trigger) {
			return fmt.Errorf("%s: supply a mapping for each expected trigger field", name)
		}
		for k, ref := range a.Expected {
			var typ string
			switch {
			case ref == "case_id":
				typ = "string"
			case strings.HasPrefix(ref, "case."):
				typ = c.Case.Fields[strings.TrimPrefix(ref, "case.")]
			case strings.HasPrefix(ref, "input."):
				typ = a.Inputs[strings.TrimPrefix(ref, "input.")]
			}
			if typ == "" || typ != trigger[k] || k == c.Case.Key && ref != "case_id" {
				return fmt.Errorf("%s: invalid expected mapping %s", name, k)
			}
		}
		for _, rule := range a.ReviewUnless {
			t := a.Inputs[rule.Input]
			if t == "" || t != c.Case.Fields[rule.Case] {
				return fmt.Errorf("%s: incompatible review fields", name)
			}
			switch rule.Op {
			case "equal":
				if rule.Timezone != "" {
					return errors.New("timezone requires same_local_day")
				}
			case "same_local_day":
				if t != "timestamp" || rule.Timezone == "" || rule.Timezone == "Local" {
					return errors.New("same_local_day requires timestamps and an explicit timezone")
				}
				if _, err := time.LoadLocation(rule.Timezone); err != nil {
					return err
				}
			default:
				return fmt.Errorf("%s: unknown review comparison", name)
			}
		}
	}
	return nil
}
func CheckActionFields(schema map[string]string, data map[string]any) error {
	if len(schema) != len(data) {
		return errors.New("action fields do not match schema")
	}
	for k, t := range schema {
		if !validValue(t, data[k]) {
			return fmt.Errorf("invalid action field %s (expected %s)", k, t)
		}
	}
	return nil
}
func (a ActionSpec) Available(state, actor string) bool {
	if state != a.From {
		return false
	}
	for _, v := range a.Actors {
		if actor == v {
			return true
		}
	}
	return false
}
func (a ActionSpec) ReviewReason(original, input map[string]any) (string, error) {
	if err := CheckActionFields(a.Inputs, input); err != nil {
		return "", err
	}
	if a.AlwaysReview {
		return "Human approval required", nil
	}
	for _, r := range a.ReviewUnless {
		left, right := input[r.Input], original[r.Case]
		equal := Digest(left) == Digest(right)
		if r.Op == "same_local_day" {
			zone, err := time.LoadLocation(r.Timezone)
			if err != nil {
				return "", err
			}
			l, err := time.Parse(time.RFC3339Nano, fmt.Sprint(left))
			if err != nil {
				return "", err
			}
			v, err := time.Parse(time.RFC3339Nano, fmt.Sprint(right))
			if err != nil {
				return "", err
			}
			equal = l.In(zone).Format(time.DateOnly) == v.In(zone).Format(time.DateOnly)
		}
		if !equal {
			return fmt.Sprintf("Review required for %s (%s)", r.Input, r.Op), nil
		}
	}
	return "", nil
}
func (a ActionSpec) ExpectedFields(caseID string, original, input map[string]any) map[string]any {
	fields := map[string]any{}
	for k, ref := range a.Expected {
		switch {
		case ref == "case_id":
			fields[k] = caseID
		case strings.HasPrefix(ref, "case."):
			fields[k] = original[ref[5:]]
		default:
			fields[k] = input[ref[6:]]
		}
	}
	return fields
}
