$ErrorActionPreference = 'Stop'
$moduleRoot = Split-Path -Parent $PSScriptRoot
$outputRoot = Join-Path $moduleRoot 'dist'
New-Item -ItemType Directory -Force -Path $outputRoot | Out-Null
$previousOS = $env:GOOS
$previousArch = $env:GOARCH
$previousCGO = $env:CGO_ENABLED
try {
    Push-Location $moduleRoot
    $env:CGO_ENABLED = '0'
    foreach ($targetOS in @('windows', 'linux', 'darwin')) {
        foreach ($targetArch in @('amd64', 'arm64')) {
            $env:GOOS = $targetOS
            $env:GOARCH = $targetArch
            $suffix = if ($targetOS -eq 'windows') { '.exe' } else { '' }
            $target = Join-Path $outputRoot "axonpush-$targetOS-$targetArch$suffix"
            go build -trimpath -ldflags='-buildid=' -o $target ./cmd/axonpush
            if ($LASTEXITCODE -ne 0) { throw "Build failed: $targetOS/$targetArch" }
        }
    }
    Get-ChildItem -LiteralPath $outputRoot -File -Filter 'axonpush-*' | Sort-Object Name | ForEach-Object {
        $digest = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        "$digest  $($_.Name)"
    } | Set-Content -LiteralPath (Join-Path $outputRoot 'SHA256SUMS') -Encoding ascii
} finally {
    Pop-Location
    $env:GOOS = $previousOS
    $env:GOARCH = $previousArch
    $env:CGO_ENABLED = $previousCGO
}
