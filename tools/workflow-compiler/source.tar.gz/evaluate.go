package workflow

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"
)

func Evaluate(b Bundle, in Input) (Result, error) {
	out := Result{CaseID: in.CaseID, SemanticHash: b.SemanticHash, EvaluatedAt: in.Now, Obligations: []Obligation{}}
	if err := validate(b.Contract); err != nil {
		return out, err
	}
	semantic := b.Contract
	semantic.Presentation = Presentation{}
	if b.CompilerVersion != Version || b.SemanticHash != Digest(semantic) {
		return out, fmt.Errorf("bundle hash or compiler version mismatch")
	}
	if in.CaseID == "" || len(in.CaseID) > 160 || in.Now.IsZero() || len(in.Facts) > 10000 {
		return out, fmt.Errorf("case_id, explicit now and at most 10000 facts required")
	}
	for k, v := range in.CaseFields {
		if !validValue(b.Contract.Case.Fields[k], v) {
			return out, fmt.Errorf("invalid case field %s", k)
		}
	}
	for k := range b.Contract.Case.Fields {
		if _, ok := in.CaseFields[k]; !ok {
			return out, fmt.Errorf("missing case field %s", k)
		}
	}
	facts := append([]Fact{}, in.Facts...)
	seen := map[string]string{}
	dedup := facts[:0]
	for _, f := range facts {
		if err := ValidateFact(b.Contract, f); err != nil {
			return out, err
		}
		if f.CaseID != in.CaseID {
			return out, fmt.Errorf("fact %s belongs to another case", f.ID)
		}
		identity := f
		identity.ReceivedAt = time.Time{}
		digest := Digest(identity)
		if previous, ok := seen[f.ID]; ok {
			if previous != digest {
				return out, fmt.Errorf("conflicting duplicate fact %s", f.ID)
			}
			continue
		}
		seen[f.ID] = digest
		if f.ReceivedAt.After(in.Now) || f.OccurredAt.After(in.Now) {
			continue
		}
		dedup = append(dedup, f)
	}
	facts = dedup
	sort.Slice(facts, func(i, j int) bool {
		if facts[i].OccurredAt.Equal(facts[j].OccurredAt) {
			return facts[i].ID < facts[j].ID
		}
		return facts[i].OccurredAt.Before(facts[j].OccurredAt)
	})
	previous := map[string]Obligation{}
	coverageSources := map[string]bool{}
	for _, c := range in.Coverage {
		if coverageSources[c.Source] || c.CheckedAt.IsZero() || c.CompleteThrough.After(c.CheckedAt) {
			return out, fmt.Errorf("duplicate or invalid source checkpoint")
		}
		coverageSources[c.Source] = true
	}
	for _, p := range in.Previous {
		previous[p.ID] = p
	}
	names := make([]string, 0, len(b.Contract.Requirements))
	comparisons := 0
	for n := range b.Contract.Requirements {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, name := range names {
		r := b.Contract.Requirements[name]
		within, _ := time.ParseDuration(r.Within)
		grace, _ := time.ParseDuration(r.Grace)
		fresh, _ := time.ParseDuration(r.FreshFor)
		for _, trigger := range facts {
			if !matches(b.Contract, r.Trigger, trigger, trigger, in.CaseFields) {
				continue
			}
			o := Obligation{ID: Digest([]string{in.CaseID, b.SemanticHash, name, trigger.ID}), Requirement: name, TriggerID: trigger.ID, State: "pending", Lifecycle: "active", Timing: "not_due", Reason: "Waiting for evidence", DueAt: trigger.OccurredAt.Add(within), EvidenceIDs: []string{}, EvidenceClass: b.Contract.Facts[r.Evidence.Event].EvidenceClass}
			o.DecideAt = o.DueAt.Add(grace)
			if p, ok := previous[o.ID]; ok {
				o.BreachObservedAt = p.BreachObservedAt
			}
			var good, failed, cancelled *Fact
			distinct := map[string]string{}
			for i := range facts {
				comparisons++
				if comparisons > 1000000 {
					return out, fmt.Errorf("case evaluation exceeds one million evidence comparisons; split the case")
				}
				f := &facts[i]
				if f.OccurredAt.Before(trigger.OccurredAt) || f.Source != r.Source {
					continue
				}
				if good == nil && matches(b.Contract, r.Evidence, *f, trigger, in.CaseFields) {
					good = f
				}
				if r.MaxMatches > 0 && matches(b.Contract, r.Evidence, *f, trigger, in.CaseFields) {
					k, _ := f.Fields[r.EvidenceKey].(string)
					distinct[k] = f.ID
				}
				if r.Failure != nil && failed == nil && matches(b.Contract, *r.Failure, *f, trigger, in.CaseFields) {
					failed = f
				}
				if r.Cancel != nil && cancelled == nil && matches(b.Contract, *r.Cancel, *f, trigger, in.CaseFields) {
					cancelled = f
				}
			}
			switch {
			case cancelled != nil:
				o.Lifecycle = "cancelled"
				o.Reason = "Explicit cancellation evidence"
				o.EvidenceIDs = []string{cancelled.ID}
			case failed != nil && good != nil:
				o.State = "unverifiable"
				o.Reason = "Conflicting success and failure evidence"
				o.EvidenceIDs = []string{failed.ID, good.ID}
			case r.MaxMatches > 0 && len(distinct) > r.MaxMatches:
				o.State = "violated"
				o.Reason = "Multiple distinct records exceed allowed evidence cardinality"
				for _, id := range distinct {
					o.EvidenceIDs = append(o.EvidenceIDs, id)
				}
				sort.Strings(o.EvidenceIDs)
				if o.BreachObservedAt == nil {
					t := in.Now
					o.BreachObservedAt = &t
				}
			case failed != nil:
				o.State = "violated"
				o.Reason = "Explicit failure evidence"
				o.EvidenceIDs = []string{failed.ID}
				if o.BreachObservedAt == nil {
					t := in.Now
					o.BreachObservedAt = &t
				}
			case good != nil:
				o.State = "satisfied"
				o.Reason = "Required evidence matched"
				o.EvidenceIDs = []string{good.ID}
				o.Timing = "fulfilled_on_time"
				if good.OccurredAt.After(o.DueAt) {
					o.Timing = "fulfilled_late"
				}
			case !in.Now.Before(o.DecideAt):
				o.Timing = "deadline_passed"
				o.State = "unverifiable"
				o.Reason = "Evidence source is unhealthy, stale or incompletely reconciled"
				for _, c := range in.Coverage {
					if c.Source == r.Source && c.Healthy && !c.CheckedAt.After(in.Now) && !c.CheckedAt.Before(in.Now.Add(-fresh)) && !c.CompleteThrough.Before(o.DueAt) && !c.CompleteThrough.After(c.CheckedAt) {
						o.State = "violated"
						o.Reason = "Deadline passed with complete source coverage"
						break
					}
				}
				if o.State == "violated" && o.BreachObservedAt == nil {
					t := in.Now
					o.BreachObservedAt = &t
				}
				if o.BreachObservedAt != nil && o.State == "unverifiable" {
					o.State = "violated"
					o.Reason = "Previously established breach; current evidence remains incomplete"
				}
			}
			out.Obligations = append(out.Obligations, o)
		}
	}
	return out, nil
}

func ValidateFact(c Contract, f Fact) error {
	s, ok := c.Facts[f.Event]
	if !ok {
		return fmt.Errorf("unknown fact event %s", f.Event)
	}
	if f.ID == "" || len(f.ID) > 160 || f.CaseID == "" || !identifier.MatchString(f.Source) || f.OccurredAt.IsZero() || f.ReceivedAt.IsZero() {
		return fmt.Errorf("fact identity, source and timestamps required")
	}
	if f.Fields[c.Case.Key] != f.CaseID {
		return fmt.Errorf("fact case key does not match case_id")
	}
	if len(f.Fields) != len(s.Fields) {
		return fmt.Errorf("fact %s has missing or undeclared fields", f.ID)
	}
	for k, t := range s.Fields {
		if !validValue(t, f.Fields[k]) {
			return fmt.Errorf("fact %s: field %s must be %s", f.ID, k, t)
		}
	}
	return nil
}
func resolve(ref string, e, t Fact, c map[string]any) any {
	p := strings.SplitN(ref, ".", 2)
	if len(p) != 2 {
		return nil
	}
	switch p[0] {
	case "trigger":
		return t.Fields[p[1]]
	case "evidence":
		return e.Fields[p[1]]
	case "case":
		return c[p[1]]
	}
	return nil
}
func equal(typ string, a, b any) bool {
	if a == nil || b == nil {
		return false
	}
	x, _ := json.Marshal(a)
	y, _ := json.Marshal(b)
	if string(x) == string(y) {
		return true
	}
	sa, aok := a.(string)
	sb, bok := b.(string)
	if typ == "timestamp" && aok && bok {
		ta, ea := time.Parse(time.RFC3339Nano, sa)
		tb, eb := time.Parse(time.RFC3339Nano, sb)
		return ea == nil && eb == nil && ta.Equal(tb)
	}
	return false
}
func matches(contract Contract, s Selector, e, t Fact, c map[string]any) bool {
	if e.Event != s.Event {
		return false
	}
	for k, v := range s.Match {
		if !equal(contract.Facts[e.Event].Fields[k], e.Fields[k], resolve(v, e, t, c)) {
			return false
		}
	}
	return predicate(contract, s.Where, e, t, c)
}
func predicate(contract Contract, p *Predicate, e, t Fact, c map[string]any) bool {
	if p == nil {
		return true
	}
	if len(p.All) > 0 {
		for _, v := range p.All {
			if !predicate(contract, &v, e, t, c) {
				return false
			}
		}
		return true
	}
	if len(p.Any) > 0 {
		for _, v := range p.Any {
			if predicate(contract, &v, e, t, c) {
				return true
			}
		}
		return false
	}
	v := resolve(p.Field, e, t, c)
	typ := fieldType(contract, Requirement{Trigger: Selector{Event: t.Event}}, Selector{Event: e.Event}, p.Field)
	switch p.Op {
	case "present":
		return v != nil
	case "eq":
		return equal(typ, v, p.Value)
	case "ne":
		return v != nil && !equal(typ, v, p.Value)
	case "in":
		for _, x := range p.Value.([]any) {
			if equal(typ, v, x) {
				return true
			}
		}
		return false
	}
	if typ == "timestamp" {
		a, aok := v.(string)
		b, bok := p.Value.(string)
		if !aok || !bok {
			return false
		}
		ta, ea := time.Parse(time.RFC3339Nano, a)
		tb, eb := time.Parse(time.RFC3339Nano, b)
		if ea != nil || eb != nil {
			return false
		}
		switch p.Op {
		case "gt":
			return ta.After(tb)
		case "gte":
			return !ta.Before(tb)
		case "lt":
			return ta.Before(tb)
		case "lte":
			return !ta.After(tb)
		}
		return false
	}
	a, aok := numeric(v)
	b, bok := numeric(p.Value)
	if !aok || !bok {
		return false
	}
	switch p.Op {
	case "gt":
		return a > b
	case "gte":
		return a >= b
	case "lt":
		return a < b
	case "lte":
		return a <= b
	}
	return false
}
func numeric(v any) (float64, bool) {
	switch x := v.(type) {
	case float64:
		return x, true
	case int:
		return float64(x), true
	case int64:
		return float64(x), true
	case string:
		t, e := time.Parse(time.RFC3339Nano, x)
		if e == nil {
			return float64(t.UnixNano()), true
		}
	}
	return 0, false
}
