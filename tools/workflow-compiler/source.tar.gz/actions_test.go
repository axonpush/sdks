package workflow

import (
	"os"
	"testing"
)

func TestActionTimezoneAndGeneratedCode(t *testing.T) {
	src, err := os.ReadFile("examples/booking-reschedule/workflow.yaml")
	if err != nil {
		t.Fatal(err)
	}
	b, err := Compile(src)
	if err != nil {
		t.Fatal(err)
	}
	a := b.Contract.Actions["reschedule"]
	original := map[string]any{"starts_at": "2026-11-24T23:00:00Z", "location": "main"}
	for _, v := range []struct {
		ts, location string
		review       bool
	}{{"2026-11-25T01:00:00Z", "main", false}, {"2026-11-25T06:00:00Z", "main", true}, {"2026-11-24T23:00:00Z", "other", true}} {
		reason, e := a.ReviewReason(original, map[string]any{"starts_at": v.ts, "location": v.location})
		if e != nil || (reason != "") != v.review {
			t.Fatalf("%+v: %s %v", v, reason, e)
		}
	}
	for _, lang := range []string{"typescript", "python"} {
		x, e := Generate(b, lang)
		if e != nil || len(x) != 5 || !x[4].UserOwned {
			t.Fatal(lang, e)
		}
		y, _ := Generate(b, lang)
		if Digest(x) != Digest(y) {
			t.Fatal("unstable generation")
		}
	}
}
