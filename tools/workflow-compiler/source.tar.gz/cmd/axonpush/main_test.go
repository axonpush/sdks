package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestBookingTemplateContainsOnlyPublishedFiles(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "booking")
	if err := run([]string{"workflow", "init", "--template", "booking-reschedule", "--out", dir}); err != nil {
		t.Fatal(err)
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	want := map[string]bool{"README.md": true, "review.json": true, "scenario.py": true, "worker.py": true, "workflow.yaml": true}
	for _, entry := range entries {
		if entry.IsDir() || !want[entry.Name()] {
			t.Fatalf("unexpected template entry %s", entry.Name())
		}
		delete(want, entry.Name())
	}
	if len(want) != 0 {
		t.Fatalf("missing template files: %v", want)
	}
}

func TestGenerationPreservesUserAdapter(t *testing.T) {
	dir := t.TempDir()
	contract := filepath.Join(dir, "workflow.yaml")
	if e := writeNew(contract, []byte(example)); e != nil {
		t.Fatal(e)
	}
	args := []string{"workflow", "generate", "--file", contract, "--out", dir}
	if e := run(args); e != nil {
		t.Fatal(e)
	}
	adapter := filepath.Join(dir, "adapter.ts")
	if e := os.WriteFile(adapter, []byte("// my implementation\n"), 0644); e != nil {
		t.Fatal(e)
	}
	if e := run(args); e != nil {
		t.Fatal(e)
	}
	body, _ := os.ReadFile(adapter)
	if string(body) != "// my implementation\n" {
		t.Fatal("user implementation overwritten")
	}
	if e := run(append(args, "--check")); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(dir, "generated.ts"), []byte("changed"), 0644); e != nil {
		t.Fatal(e)
	}
	if e := run(append(args, "--check")); e == nil {
		t.Fatal("drift not detected")
	}
}
