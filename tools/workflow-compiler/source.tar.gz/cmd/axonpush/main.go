package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	workflow "github.com/axonpush/workflow"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		_ = json.NewEncoder(os.Stderr).Encode(map[string]string{"error": err.Error()})
		os.Exit(1)
	}
}
func run(args []string) error {
	if len(args) == 2 && args[0] == "workflow" && args[1] == "version" {
		return json.NewEncoder(os.Stdout).Encode(map[string]string{"version": workflow.Version})
	}
	if len(args) < 2 || args[0] != "workflow" {
		return errors.New("usage: axonpush workflow <init|validate|generate|test|action-test|diff|publish> [flags]")
	}
	fs := flag.NewFlagSet(args[1], flag.ContinueOnError)
	template := fs.String("template", "", "install booking-reschedule into a new --out directory")
	file := fs.String("file", "workflow.yaml", "contract source")
	lang := fs.String("language", "typescript", "typescript or python")
	out := fs.String("out", ".axonpush/workflow", "generated output directory")
	check := fs.Bool("check", false, "check generated output without writing")
	dry := fs.Bool("dry-run", false, "print artifacts without writing")
	fixture := fs.String("fixture", "", "JSON evaluation input")
	other := fs.String("against", "", "other contract for diff")
	url := fs.String("url", "", "AxonPush API URL")
	workspace := fs.String("workspace", "", "workspace ID")
	if e := fs.Parse(args[2:]); e != nil {
		return e
	}
	if args[1] == "init" {
		if *template != "" {
			if *template != "booking-reschedule" {
				return errors.New("unknown workflow template")
			}
			root, e := filepath.Abs(*out)
			if e != nil {
				return e
			}
			if e = rejectLinks(root); e != nil {
				return e
			}
			if e = os.MkdirAll(filepath.Dir(root), 0755); e != nil {
				return e
			}
			if e = os.Mkdir(root, 0755); e != nil {
				return e
			}
			entries, e := workflow.Packages.ReadDir("examples/booking-reschedule")
			if e != nil {
				return e
			}
			for _, entry := range entries {
				data, e := workflow.Packages.ReadFile("examples/booking-reschedule/" + entry.Name())
				if e != nil {
					return e
				}
				if e = writeNew(filepath.Join(root, entry.Name()), data); e != nil {
					return e
				}
			}
			return nil
		}
		return writeNew(*file, []byte(example))
	}
	source, e := os.ReadFile(*file)
	if e != nil {
		return e
	}
	b, e := workflow.Compile(source)
	if e != nil {
		return e
	}
	switch args[1] {
	case "action-test":
		var scenario struct {
			Action   string         `json:"action"`
			Actor    string         `json:"actor"`
			State    string         `json:"state"`
			Original map[string]any `json:"original"`
			Input    map[string]any `json:"input"`
			Expected string         `json:"expected"`
		}
		data, err := os.ReadFile(*fixture)
		if err != nil {
			return err
		}
		decoder := json.NewDecoder(bytes.NewReader(data))
		decoder.DisallowUnknownFields()
		if err = decoder.Decode(&scenario); err != nil {
			return err
		}
		spec, ok := b.Contract.Actions[scenario.Action]
		if !ok {
			return errors.New("unknown action")
		}
		if err = workflow.CheckActionFields(b.Contract.Case.Fields, scenario.Original); err != nil {
			return err
		}
		status, reason := "unavailable", "action unavailable for actor or case state"
		if spec.Available(scenario.State, scenario.Actor) {
			reason, err = spec.ReviewReason(scenario.Original, scenario.Input)
			if err != nil {
				return err
			}
			status = "ready"
			if reason != "" {
				status = "review"
			}
		}
		if scenario.Expected != status {
			return fmt.Errorf("expected %s, got %s", scenario.Expected, status)
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]string{"status": status, "reason": reason})
	case "validate":
		return json.NewEncoder(os.Stdout).Encode(b)
	case "diff":
		s, e := os.ReadFile(*other)
		if e != nil {
			return e
		}
		old, e := workflow.Compile(s)
		if e != nil {
			return e
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"semantic_changed": old.SemanticHash != b.SemanticHash, "source_changed": old.SourceHash != b.SourceHash, "before": old, "after": b})
	case "test":
		f, e := os.ReadFile(*fixture)
		if e != nil {
			return e
		}
		var in workflow.Input
		var fixture struct {
			Input    *workflow.Input   `json:"input"`
			Expected map[string]string `json:"expected"`
		}
		if e = json.Unmarshal(f, &fixture); e != nil {
			return e
		}
		if fixture.Input != nil {
			in = *fixture.Input
		} else {
			d := json.NewDecoder(bytes.NewReader(f))
			d.DisallowUnknownFields()
			if e = d.Decode(&in); e != nil {
				return e
			}
		}
		r, e := workflow.Evaluate(b, in)
		if e != nil {
			return e
		}
		for requirement, state := range fixture.Expected {
			found := false
			for _, o := range r.Obligations {
				if o.Requirement == requirement {
					found = true
					if o.State != state {
						return fmt.Errorf("%s: expected %s, got %s", requirement, state, o.State)
					}
				}
			}
			if !found {
				return fmt.Errorf("expected requirement %s was not instantiated", requirement)
			}
		}
		return json.NewEncoder(os.Stdout).Encode(r)
	case "generate":
		artifacts, e := workflow.Generate(b, *lang)
		if e != nil {
			return e
		}
		if *dry {
			return json.NewEncoder(os.Stdout).Encode(artifacts)
		}
		root, e := filepath.Abs(*out)
		if e != nil {
			return e
		}
		if e = rejectLinks(root); e != nil {
			return e
		}
		for _, a := range artifacts {
			if filepath.Base(a.Path) != a.Path {
				return errors.New("unsafe artifact path")
			}
			path := filepath.Join(root, a.Path)
			if e = rejectLinks(path); e != nil {
				return e
			}
			current, e := os.ReadFile(path)
			if e != nil && !os.IsNotExist(e) {
				return e
			}
			if a.UserOwned && e == nil {
				continue
			}
			if *check {
				if e != nil || string(current) != a.Content {
					return fmt.Errorf("generated output differs: %s", a.Path)
				}
				continue
			}
			if e = os.MkdirAll(root, 0755); e != nil {
				return e
			}
			if a.UserOwned {
				e = writeNew(path, []byte(a.Content))
			} else {
				e = os.WriteFile(path, []byte(a.Content), 0644)
			}
			if e != nil {
				return e
			}
		}
		return nil
	case "publish":
		if *workspace == "" || *url == "" {
			return errors.New("--url and --workspace required")
		}
		if !strings.HasPrefix(*url, "https://") && !strings.HasPrefix(*url, "http://localhost:") && !strings.HasPrefix(*url, "http://127.0.0.1:") {
			return errors.New("HTTPS required except localhost")
		}
		key := os.Getenv("AXONPUSH_API_KEY")
		if key == "" {
			return errors.New("AXONPUSH_API_KEY required")
		}
		body, _ := json.Marshal(map[string]string{"source": string(source)})
		req, e := http.NewRequest("POST", strings.TrimRight(*url, "/")+"/workspaces/"+*workspace+"/workflows/definitions", bytes.NewReader(body))
		if e != nil {
			return e
		}
		req.Header.Set("Authorization", "Bearer "+key)
		req.Header.Set("Content-Type", "application/json")
		client := &http.Client{Timeout: 30 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
		resp, e := client.Do(req)
		if e != nil {
			return e
		}
		defer resp.Body.Close()
		data, e := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
		if e != nil {
			return e
		}
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			return fmt.Errorf("publish failed: HTTP %d", resp.StatusCode)
		}
		_, e = os.Stdout.Write(data)
		return e
	default:
		return fmt.Errorf("unknown command %s", args[1])
	}
}
func rejectLinks(path string) error {
	for {
		fi, e := os.Lstat(path)
		if e == nil && fi.Mode()&os.ModeSymlink != 0 {
			return fmt.Errorf("symlink output path rejected: %s", path)
		}
		if e != nil && !os.IsNotExist(e) {
			return e
		}
		parent := filepath.Dir(path)
		if parent == path {
			return nil
		}
		path = parent
	}
}
func writeNew(path string, data []byte) error {
	f, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if e != nil {
		return e
	}
	_, e = f.Write(data)
	closeErr := f.Close()
	if e != nil {
		return e
	}
	return closeErr
}

const example = `schema_version: 1
workflow: example
case:
  key: request_id
facts:
  request.accepted:
    fields: { request_id: string }
  request.completed:
    fields: { request_id: string }
    evidence_class: application_record
requirements:
  completion:
    trigger: { event: request.accepted }
    within: 2m
    grace: 5m
    source: application
    fresh_for: 10m
    evidence:
      event: request.completed
      match: { request_id: trigger.request_id }
presentation:
  title: Example workflow
`
