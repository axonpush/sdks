package workflow

import (
	"fmt"
	"maps"
	"slices"
	"strings"
)

// Action code lives in its own module so action identifiers cannot shadow fact builders.
func generateActionTypes(b Bundle, py bool) []Artifact {
	var code, stub strings.Builder
	ext := "ts"
	if py {
		ext = "py"
		code.WriteString("from typing import TypedDict, Protocol\n\n")
		stub.WriteString("# User-owned handlers\nfrom .actions import *\n\n")
	} else {
		stub.WriteString("// User-owned handlers\nimport type * as Types from './actions';\n")
	}
	for _, name := range slices.Sorted(maps.Keys(b.Contract.Actions)) {
		a := b.Contract.Actions[name]
		prefix := strings.TrimSuffix(typeName(name), "Fields")
		for _, shape := range []struct {
			name   string
			fields map[string]string
		}{{"Input", a.Inputs}, {"Output", a.Outputs}} {
			if py {
				fmt.Fprintf(&code, "class %s%s(TypedDict):\n", prefix, shape.name)
			} else {
				fmt.Fprintf(&code, "export interface %s%s {\n", prefix, shape.name)
			}
			for _, key := range slices.Sorted(maps.Keys(shape.fields)) {
				typ := shape.fields[key]
				if py {
					typ = map[string]string{"string": "str", "timestamp": "str", "boolean": "bool", "number": "float"}[typ]
				} else if typ == "timestamp" {
					typ = "string"
				}
				fmt.Fprintf(&code, "    %s: %s\n", key, typ)
			}
			if !py {
				code.WriteString("}\n")
			}
			code.WriteString("\n")
		}
		if py {
			fmt.Fprintf(&code, "def propose_%s(request_id: str, data: %sInput) -> dict:\n    return {'name': %q, 'request_id': request_id, 'input': data}\n\nclass %sHandler(Protocol):\n    def __call__(self, operation_id: str, original: dict, data: %sInput) -> %sOutput: ...\n\n", name, prefix, name, prefix, prefix, prefix)
			fmt.Fprintf(&stub, "def execute_%s(operation_id: str, original: dict, data: %sInput) -> %sOutput:\n    raise NotImplementedError('Implement the version-checked provider write')\n\n", name, prefix, prefix)
		} else {
			fmt.Fprintf(&code, "export function propose%s(request_id: string, input: %sInput) { return {name: %q as const, request_id, input}; }\nexport type %sHandler = (operationId: string, original: Record<string, unknown>, input: %sInput) => Promise<%sOutput>;\n", prefix, prefix, name, prefix, prefix, prefix)
			fmt.Fprintf(&stub, "export const execute%s: Types.%sHandler = async (_operationId, _original, _input) => { throw new Error('Implement the version-checked provider write'); };\n", prefix, prefix)
		}
	}
	return []Artifact{{Path: "actions." + ext, Content: code.String()}, {Path: "handlers." + ext, Content: stub.String(), UserOwned: true}}
}
