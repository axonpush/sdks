package workflow

import (
	"fmt"
	"os"
	"strings"
	"testing"
	"time"
)

func booking(t *testing.T) (Bundle, Input) {
	t.Helper()
	src, e := os.ReadFile("examples/booking.yaml")
	if e != nil {
		t.Fatal(e)
	}
	b, e := Compile(src)
	if e != nil {
		t.Fatal(e)
	}
	now := time.Date(2026, 11, 20, 10, 0, 0, 0, time.UTC)
	f := Fact{ID: "accepted", Event: "booking.accepted", CaseID: "request-1", Source: "booking_adapter", OccurredAt: now, ReceivedAt: now, Fields: map[string]any{"booking_request_id": "request-1", "person_ref": "person-1", "starts_at": "2026-11-21T10:00:00Z", "service_ref": "service-1"}}
	return b, Input{CaseID: f.CaseID, Now: now, Facts: []Fact{f}}
}
func TestDeadlineCoverageAndLateEvidence(t *testing.T) {
	b, in := booking(t)
	r, e := Evaluate(b, in)
	if e != nil || r.Obligations[0].State != "pending" {
		t.Fatalf("%+v %v", r, e)
	}
	in.Now = in.Now.Add(8 * time.Minute)
	r, e = Evaluate(b, in)
	if e != nil || r.Obligations[0].State != "unverifiable" {
		t.Fatalf("%+v %v", r, e)
	}
	in.Coverage = []Coverage{{Source: "booking_adapter", Healthy: true, CheckedAt: in.Now, CompleteThrough: in.Now}}
	r, e = Evaluate(b, in)
	if e != nil || r.Obligations[0].State != "violated" {
		t.Fatalf("%+v %v", r, e)
	}
	in.Previous = r.Obligations
	f := in.Facts[0]
	f.Fields = map[string]any{"booking_request_id": "request-1", "person_ref": "person-1", "starts_at": "2026-11-21T10:00:00Z", "service_ref": "service-1", "booking_ref": "b-1"}
	f.ID = "record"
	f.Event = "booking.record_observed"
	f.OccurredAt = in.Now
	f.ReceivedAt = in.Now
	in.Facts = append(in.Facts, f)
	r, e = Evaluate(b, in)
	if e != nil || r.Obligations[0].State != "satisfied" || r.Obligations[0].Timing != "fulfilled_late" || r.Obligations[0].BreachObservedAt == nil {
		t.Fatalf("%+v %v", r, e)
	}
}
func TestDuplicateConflictAndOrder(t *testing.T) {
	b, in := booking(t)
	in.Facts = append(in.Facts, in.Facts[0])
	r, e := Evaluate(b, in)
	if e != nil || len(r.Obligations) != 1 {
		t.Fatalf("%+v %v", r, e)
	}
	in.Facts[1].Source = "other"
	if _, e := Evaluate(b, in); e == nil {
		t.Fatal("conflict accepted")
	}
}
func TestCompileSafetyAndPresentationHash(t *testing.T) {
	src, _ := os.ReadFile("examples/booking.yaml")
	b, e := Compile(src)
	if e != nil {
		t.Fatal(e)
	}
	edited := strings.Replace(string(src), "title: Appointment booking", "title: Different label", 1)
	c, e := Compile([]byte(edited))
	if e != nil || b.SemanticHash != c.SemanticHash || b.SourceHash == c.SourceHash {
		t.Fatal("presentation changes semantic identity")
	}
	for _, bad := range []string{string(src) + "\nworkflow: duplicate", string(src) + "\nunknown: true", strings.Replace(string(src), "schema_version: 1", "schema_version: 2", 1), strings.Replace(string(src), "title: Appointment booking", "title: &anchor Label", 1)} {
		if _, e := Compile([]byte(bad)); e == nil {
			t.Fatal("unsafe source accepted")
		}
	}
}
func TestNovaConditionalTrigger(t *testing.T) {
	src, _ := os.ReadFile("examples/nova.yaml")
	b, e := Compile(src)
	if e != nil {
		t.Fatal(e)
	}
	now := time.Now().UTC()
	in := Input{CaseID: "app-1", Now: now, Facts: []Fact{{ID: "ratified", Event: "application.ratified", CaseID: "app-1", Source: "nova_outbox", OccurredAt: now, ReceivedAt: now, Fields: map[string]any{"application_id": "app-1", "passport_required": false, "passport_enabled": true}}}}
	r, e := Evaluate(b, in)
	if e != nil || len(r.Obligations) != 0 {
		t.Fatalf("%+v %v", r, e)
	}
	in.Facts[0].Fields["passport_required"] = true
	r, e = Evaluate(b, in)
	if e != nil || len(r.Obligations) != 1 {
		t.Fatalf("%+v %v", r, e)
	}
}

func TestDistinctBookingsAndTimestampTypes(t *testing.T) {
	b, in := booking(t)
	for i, id := range []string{"booking-a", "booking-a", "booking-b"} {
		f := Fact{ID: fmt.Sprintf("record-%d", i), CaseID: in.CaseID, Event: "booking.record_observed", Source: "booking_adapter", OccurredAt: in.Now, ReceivedAt: in.Now, Fields: map[string]any{"booking_request_id": in.CaseID, "person_ref": "person-1", "starts_at": "2026-11-21T15:30:00+05:30", "service_ref": "service-1", "booking_ref": id}}
		in.Facts = append(in.Facts, f)
		out, e := Evaluate(b, in)
		if e != nil {
			t.Fatal(e)
		}
		want := "satisfied"
		if i == 2 {
			want = "violated"
		}
		if out.Obligations[0].State != want {
			t.Fatalf("distinct records: got %s want %s", out.Obligations[0].State, want)
		}
	}
	if equal("string", "2026-11-21T10:00:00Z", "2026-11-21T15:30:00+05:30") {
		t.Fatal("string identifiers must not be timestamp-normalized")
	}
}
