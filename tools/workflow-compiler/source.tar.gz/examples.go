package workflow

import "embed"

//go:embed examples/booking-reschedule/*
var Packages embed.FS

//go:embed examples/booking.yaml
var bookingExample string

//go:embed examples/booking-missed.json
var missedBookingExample string

// BookingExample returns the repository's canonical, synthetic booking contract
// and missing-record fixture. Callers can simulate them without external access.
// The returned strings cannot mutate the embedded examples.
func BookingExample() (source, fixture string) {
	return bookingExample, missedBookingExample
}
