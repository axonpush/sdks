# Workflow contracts

Apache-2.0 compiler, deterministic verifier and local code generator. No model
calls, network evaluation, credentials or business-action execution.

Build with `go build -o dist/axonpush.exe ./cmd/axonpush` on Windows, or select an
appropriate output name on other platforms. `scripts/release.ps1` cross-compiles
Windows, Linux and macOS amd64/arm64 binaries and creates `dist/SHA256SUMS`.
Artifacts are local; publishing a package or release is separate.

```sh
go test ./... -timeout 45s
go run ./cmd/axonpush workflow validate --file examples/booking.yaml
go run ./cmd/axonpush workflow generate --file examples/booking.yaml --language typescript --out dist/booking-ts
go run ./cmd/axonpush workflow generate --file examples/nova.yaml --language python --out dist/nova-python
```

See the product documentation's Workflow verification page for schema, fixtures,
privacy, server integration and versioning. The server imports this module using
a local Go module replacement; the same evaluator runs both locally and hosted.

Limits: 256 KiB source, 100 fact schemas, 100 requirements, 10,000 facts per case,
bounded expression depth and one million evidence comparisons per evaluation.
The hosted API further caps a request to 1 MiB and each stored case to 4 MiB.

Types are explicit. Unknown fields, duplicate YAML keys, aliases, anchors,
custom tags and arbitrary code are rejected. Every field in a declared fact is
required. Regeneration preserves user-owned adapter implementations.
